import java.util.Scanner;

public class MatrixSum {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int[][] matrix = new int[3][3];
        int sum = 0;

        System.out.println("Enter 9 values for the 3 x 3 matrix:");
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                System.out.print("Enter value for position [" + row + "][" + col + "]: ");
                matrix[row][col] = scan.nextInt();
            }
        }

        System.out.println("\nThe matrix is:");
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                System.out.print(matrix[row][col] + "\t");
                sum += matrix[row][col];
            }
            System.out.println();
        }

        System.out.println("\nSum of all elements: " + sum);

        scan.close();
    }
}
